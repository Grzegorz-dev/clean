
export default function HowItWorks(){
  return (
    <main className="paper">
      <h1>Jak to działa</h1>
      <ol>
        <li>Załóż konto jako Klient lub Usługodawca.</li>
        <li>Uzupełnij profil – zdjęcie, opis, usługi, dostępność.</li>
        <li>Klienci wyszukują profile, kontaktują się i składają zamówienia.</li>
        <li>Płatności i szczegóły ustalacie między sobą (MVP).</li>
      </ol>
    </main>
  );
}
